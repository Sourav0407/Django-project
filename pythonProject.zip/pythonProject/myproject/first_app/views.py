from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Logindetail
from django.contrib import messages
# Create your views here.
def home(request):
    return render(request,'home.html')
def display(request):
    ans=request.POST['fname']
    return render(request,'index.html',{'ans':ans})
def signup(request):
    return render(request,'signup.html')
def login(request):
    return render(request,'login.html')
def detailentry(request):
    n=request.POST['name']
    e = request.POST['email']
    p = request.POST['pass']
    o_ref=Logindetail(name=n,email=e,password=p)
    try:
        ispresent = Logindetail.objects.get(email=e)
        return render(request,'popup.html')
    except:
        o_ref.save()
        return render(request, 'index.html', {'ispresent': 'account created'})
def verification(request):
    e = request.POST['email']
    p = request.POST['pass']
    try:
        ispresent=Logindetail.objects.get(email=e)
        if(Logindetail.objects.filter(email=e)):
            try:
                a=Logindetail.objects.filter(email=e,password=p)
                if(len(a)==1):
                    return render(request,'popup1.html')
                else:
                    return render(request, 'invlidpassword.html')
            except:
                return redirect('signup')

    except:

        return render(request,'signup.html')











