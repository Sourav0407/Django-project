from django.urls import path
from . import views
urlpatterns=[
    path(r'detailentry',views.detailentry,name='detail'),
    path(r'signup',views.signup,name='signup'),
    path(r'',views.home,name='home'),
    path(r'login',views.login,name='login'),
    path(r'home',views.home,name='home_page'),
    path(r'verification',views.verification,name='verification'),

]